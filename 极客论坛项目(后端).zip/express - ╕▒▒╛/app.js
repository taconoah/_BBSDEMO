const express = require('express');
const cors = require('cors');
const data = require('./controllers/datas.js');
const { expressjwt } = require('express-jwt');
const app = express();
app.use(express.json());
app.use(cors());
app.use(
    expressjwt({ secret: 'welcome to my house :)', algorithms: ["HS256"] }).unless({
        path: [/^\/api\//],
    })
);
app.use((err, req, res, next) => {
    res.send({
        message: 'server is not found',
        status: 400,
    });
});
app.use(data);
app.listen(80, () => {
    console.log("服务器启动成功,地址为:http://127.0.0.1/");
});