const express = require('express');
const Datas = express.Router();
const jwt = require('jsonwebtoken');

// 我的密钥
const secretKey = 'welcome to my house :)';
const SqlService = require('../services/SqlServer.js');

Datas.get('/', (req, res) => {
    res.send({
        username: req.auth.val[0].username,
        identity: req.auth.val[0].user_sf,
        message: '成功获取到数据',
    });
});

Datas.get('/api/test', (req, res) => {
    res.send({
        message: '成功获取到数据',
    });
});
Datas.get('/pages/article', (req, res) => {
    SqlService(`
    SELECT articles.article_id, articles.title, articles.content, DATE_FORMAT(articles.publication_time, '%Y-%m-%d %H:%i:%s') AS publication_time_formatted, 
    users.username FROM articles
    JOIN users ON articles.user_id = users.user_id
    ORDER BY articles.publication_time DESC;
        `,
        callback = (val) => {
            res.send(val)
        });
});
Datas.get('/pages/comments', (req, res) => {
    SqlService(`
    SELECT comments.comment_id, comments.comment_text, users.username, comments.article_id, DATE_FORMAT(comments.publication_time, '%Y-%m-%d %H:%i:%s') AS formatted_publication_time
    FROM comments
    JOIN users ON comments.user_id = users.user_id
    ORDER BY comments.publication_time DESC;
    `,
        callback = (val) => {
            res.send(val)
        });
});

Datas.post('/api/login', (req, res) => {
    let { name, pwd } = req.body;
    SqlService("select * from users where username = ? and passwords = ?",
        callback = (val) => {
            if (val.length == 0) res.send({ message: '用户名或密码错误' });
            else res.send(jwt.sign({ val }, secretKey, { expiresIn: '24h' }));
        }, name, pwd);
});

Datas.post('/pages/articles/upload', (req, res) => {
    let { title, time, content } = req.body;

    SqlService(`INSERT INTO articles (title, content,user_id,publication_time)
    VALUES (?,?,?,?)`,
        callback = (val) => {
            val == undefined ? res.send({ message: '上传失败' }) : res.send({
                message: '上传成功'
            });
        }, title, content, req.auth.val[0].user_id, time);
});

Datas.post('/pages/comments/upload', (req, res) => {
    let { time, content, article_id } = req.body;
    SqlService(`INSERT INTO comments (comment_text, user_id, article_id, publication_time)
    VALUES (?,?,?,?)`,
        callback = (val) => {
            val == undefined ? res.send({ message: '上传失败' }) : res.send({
                message: '上传成功'
            })
        }, content, req.auth.val[0].user_id, article_id, time);
});

Datas.post('/pages/article/delete', async (req, res) => {
    let { ID } = req.body;
    await SqlService(`DELETE FROM comments WHERE comments.article_id = ?;`, () => { }, ID);
    await SqlService(`DELETE FROM articles WHERE articles.article_id = ?;`, () => { }, ID);
    res.send({
        message: '删除成功',
    });
});



module.exports = Datas;