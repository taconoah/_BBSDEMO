const express = require('express');
const cors = require('cors');
const data = require('./controllers/user.js');
const postings = require('./controllers/postings.js');
const test = require('./controllers/upload.js')
const { expressjwt } = require('express-jwt');
const app = express();
app.use((err, req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");

    res.send({
        message: 'server is not found',
        status: 400,
    });
});
app.use(express.json()).use(cors()).use(express.static('upload'));
app.use(
    expressjwt({ secret: 'welcome to my house :)', algorithms: ["HS256"] }).unless({
        path: [/^\/user\//, /^\/upload\//],
    })
)

app.use(data).use(postings).use(test);
app.listen(80, () => {
    console.log("服务器启动成功,地址为:http://127.0.0.1/");
});