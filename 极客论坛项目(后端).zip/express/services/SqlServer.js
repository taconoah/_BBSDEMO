const sql = require('../model/SqlTools.js');
queryList = (que, callback, ...arg) => {
    return new Promise((resolve, reject) => {
        sql.query(que, arg, (err, results) => {
            if (err) {
                console.error(err, '报错');
                reject(err);
            } else {
                resolve(callback(results == undefined ? undefined : results));
            }
        });
    });
};

module.exports = queryList;