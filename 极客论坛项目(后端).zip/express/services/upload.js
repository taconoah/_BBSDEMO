const SqlService = require('./SqlServer.js');
const multer = require('multer');
const fs = require('fs');
const paths = require('path');
const storage = multer.diskStorage({
    destination: function (req, res, cb) {
        cb(null, 'upload');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + file.originalname);
    }
});
const upload = multer({
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024,
        files: 2
    },
    fileFilter: function (req, file, cb) {
        const extAccepttable = ['.jpg', '.jpeg', '.png'];
        if (!extAccepttable.includes(paths.extname(file.originalname))) return cb(new Error('Invaild file' + file.originalname));
        cb(null, true);
    }
});
async function UploadMethods(req, res) {
    const { data } = req.body;
    // 查询是否上传过图片
    let result = await SqlService('select * from users where username = ?', callback = (val) => val[0].img != null ? true : false, JSON.parse(data).username);
    // 是否删除上次上传的图片
    if (result) {
        let result2 = await SqlService('select * from users where username = ?', callback = (val) => val[0].img, JSON.parse(data).username);
        fs.unlink(`${result2}`, err => { });
    }
    // 上传图片
    await SqlService('update users set img = ? where username = ?', callback = (val) => { }, `http://127.0.0.1/${req.file.path.replace(/\\/g, '/')}`, JSON.parse(data).username);

    res.send({
        status: 200,
        message: "上传成功",
    });
};
function UploadHref(req, res) {
    const filename = req.params.filename;
    const imagePath = paths.join(__dirname, '../upload', filename.replace(/\\/g, '/')); // 根据实际情况设置图片目录
    // 返回图片数据
    res.sendFile(imagePath);
};
module.exports = {
    upload,
    UploadMethods,
    UploadHref
};