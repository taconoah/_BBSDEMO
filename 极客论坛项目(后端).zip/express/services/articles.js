const SqlService = require('./SqlServer.js');

// 获取文章
function GetArticle(req, res) {
    SqlService(`
    SELECT articles.article_id, articles.title, articles.content, DATE_FORMAT(articles.publication_time, '%Y-%m-%d %H:%i:%s') AS publication_time_formatted, 
    users.username, users.img AS user_img
    FROM articles
    JOIN users ON articles.user_id = users.user_id
    ORDER BY articles.publication_time DESC;
            `,
        callback = (val) => {
            res.send(val)
        });
}

// 删除文章
async function DeleteArticle(req, res) {
    let { ID } = req.body;
    await SqlService(`DELETE FROM comments WHERE comments.article_id = ?;`, () => { }, ID);
    await SqlService(`DELETE FROM articles WHERE articles.article_id = ?;`, () => { }, ID);
    res.send({
        message: '删除成功',
    });
}

// 上传文章接口
function UploadArticle(req, res) {
    let { title, time, content } = req.body;

    SqlService(`INSERT INTO articles (title, content,user_id,publication_time)
        VALUES (?,?,?,?)`,
        callback = (val) => {
            val == undefined ? res.send({ message: '上传失败' }) : res.send({
                message: '上传成功'
            });
        }, title, content, req.auth.val[0].user_id, time);
}

module.exports = {
    GetArticle,
    DeleteArticle,
    UploadArticle
};
