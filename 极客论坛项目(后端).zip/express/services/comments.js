const SqlService = require('./SqlServer.js');

// 获取评论接口
function GetComments(req, res) {
    SqlService(`
    SELECT comments.comment_id, comments.comment_text, users.username, comments.article_id, DATE_FORMAT(comments.publication_time, '%Y-%m-%d %H:%i:%s') AS formatted_publication_time, 
    users.img AS user_img
    FROM comments
    JOIN users ON comments.user_id = users.user_id
    ORDER BY comments.publication_time DESC;
        `,
        callback = (val) => {
            res.send(val);
        });
}
// 上传评论接口
function uploadComments(req, res) {
    let { time, content, article_id } = req.body;
    SqlService(`INSERT INTO comments (comment_text, user_id, article_id, publication_time)
        VALUES (?,?,?,?)`,
        callback = (val) => {
            val == undefined ? res.send({ message: '上传失败' }) : res.send({
                message: '上传成功'
            })
        }, content, req.auth.val[0].user_id, article_id, time);
}
module.exports = {
    GetComments,
    uploadComments
};
