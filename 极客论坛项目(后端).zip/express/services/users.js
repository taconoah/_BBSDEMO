const SqlService = require('./SqlServer.js');
const jwt = require('jsonwebtoken');

// 我的密钥
const secretKey = 'welcome to my house :)';
// 获取用户信息
async function getInfo(req, res) {
    let img = await SqlService('SELECT * FROM USERS WHERE username = ?', callback = (val) => val[0].img, req.auth.val[0].username);
    res.send({
        username: req.auth.val[0].username,
        identity: req.auth.val[0].user_sf,
        avatar: img == null ? false : img,
        message: '成功获取到数据',
    });
}
// 登录接口
function Login(req, res) {
    let { name, pwd } = req.body;
    SqlService("SELECT * FROM USERS WHERE username = ? and passwords = ?",
        callback = (val) => {
            if (val.length == 0) res.send({ message: '用户名或密码错误' });
            else res.send(jwt.sign({ val }, secretKey, { expiresIn: '24h' }));
        }, name, pwd);
}

// 注册接口
async function register(req, res) {
    let { name, pwd, time } = req.body;
    let temp = 409;
    let response = await SqlService("select * from users where username = ?", callback = val => { return val }, name);
    if (response.length == 0) {
        await SqlService("INSERT INTO users (username, passwords, user_sf, registration_time) VALUES (?, ?, '用户', ?)", callback = val => { }, name, pwd, time);
        temp = 200;
    }
    res.send({
        status: temp,
        message: temp == 409 ? '用户名已存在' : '注册成功',
    })
}

// 注销接口
async function SignOut(req, res) {
    const { name } = req.body;
    try {
        const user = await SqlService('SELECT * FROM users WHERE username = ?', (val) => val, name);
        // 查找用户自己文章的ID
        const articles = await SqlService('SELECT * FROM articles WHERE user_id = ?', (val) => val, user[0].user_id);
        // 删除用户自己的评论
        await SqlService('DELETE FROM comments WHERE user_id = ?', () => { }, user[0].user_id);
        // 删除用户自己文章上的评论
        articles.map(async (item) => await SqlService('DELETE FROM comments WHERE article_id = ?', () => { }, item.article_id));
        // 删除用户自己的文章
        await SqlService('DELETE FROM articles WHERE user_id = ?', () => { }, user[0].user_id);
        // 删除用户账号
        await SqlService('DELETE FROM users WHERE user_id = ?', () => { }, user[0].user_id);
        res.send({
            status: 200,
            message: '注销成功',
        });
    } catch (err) {
        res.send({
            status: 500,
            message: '删除用户时出错',
        });
    }
}


module.exports = {
    getInfo,
    Login,
    register,
    SignOut
};
