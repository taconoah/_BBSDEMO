const mysql = require('mysql');

// sql
const sql = mysql.createConnection({
    user: 'root',
    password: '123456',
    host: 'localhost',
    database: 'userlist',
});

sql.connect(err => {
    if(err) console.error(err,"连接失败")
    else console.log('连接成功')
});


module.exports = sql;