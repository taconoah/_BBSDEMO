const express = require('express');
const Datas = express.Router();
const { upload, UploadHref, UploadMethods } = require('../services/upload.js');
Datas.post('/api/profile', upload.single('avatar'), async (req, res) => UploadMethods(req, res));
Datas.get('/upload/:filename', (req, res) => UploadHref(req, res));
module.exports = Datas;