const express = require('express');
const Datas = express.Router();
const article = require('../services/articles');
const comment = require('../services/comments');
Datas.get('/pages/test', (req, res) => {
    res.send("ok");
});
Datas.get('/pages/article', (req, res) => article.GetArticle(req, res));
Datas.post('/pages/article/upload', (req, res) => article.UploadArticle(req, res));
Datas.post('/pages/article/delete', (req, res) => article.DeleteArticle(req, res));
Datas.get('/pages/comments', (req, res) => comment.GetComments(req, res));
Datas.post('/pages/comments/upload', (req, res) => comment.uploadComments(req, res));
module.exports = Datas;