const express = require('express');
const Datas = express.Router();
const User = require('../services/users.js');
Datas.get('/', (req, res) => User.getInfo(req, res));
Datas.post('/user/login', (req, res) => User.Login(req, res));
Datas.post('/user/register', (req, res) => User.register(req, res));
Datas.post('/user/SignOut', (req, res) => User.SignOut(req, res));
module.exports = Datas;
