import { createRouter, createWebHistory } from 'vue-router'
import AxiosUser from '../JsTools/AxiosUsers'
import Indexpages from '../views/Indexview.vue'
import Studypages from '../views/StudyView.vue'
import Loginpages from '../views/LoginView.vue'
import ProFilePages from '../views/ProFileView.vue'
import Detailpages from '../views/DetailView.vue'
import NotFound from '../views/404view.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      redirect: '/login'
    },
    {
      path: '/index',
      name: 'Index',
      component: Indexpages
    },
    {
      path: '/Study',
      name: 'Study',
      component: Studypages
    },
    {
      path: '/login',
      name: 'login',
      component: Loginpages
    },
    {
      path: '/Profile',
      name: 'Profile',
      component: ProFilePages
    },
    {
      path: '/details/:id',
      name: 'Details',
      component: Detailpages
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: NotFound
    },
  ],
  state: () => ({
    About: [],
  }),
  // 在路由切换时将数据保存到持久化状态
  // 该方法将在每次路由切换时调用
  persistState(to, from, savedState) {
    savedState.About = this.state.About;
  }
});

router.beforeEach(async (to, from, next) => {
  await AxiosUser().then(val => {
    if (val.data.message !== '成功获取到数据' && to.path != '/login') {
      localStorage.clear();
      return next('/login');
    } else {
      if (val.data.message == '成功获取到数据' && to.path == '/login') return next('/index');
      return next();
    }
  }).catch(err => {
    next();
  });
});
export default router;