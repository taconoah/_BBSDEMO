import { createRouter, createWebHistory } from 'vue-router'
import AxiosUser from '../JsTools/AxiosUsers'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/login'  // 修正重定向路径
    },
    {
      path: '/index',
      name: 'Index',
      component: () => import(/* webpackChunkName: "Index" */ '../views/Indexview.vue')
    },
    {
      path: '/Study',
      name: 'Study',
      component: () => import(/* webpackChunkName: "Study" */ '../views/StudyView.vue')
    },
    {
      path: '/login',
      name: 'login',
      component: () => import(/* webpackChunkName: "Login" */ '../views/LoginView.vue')
    },
    {
      path: '/Profile',
      name: 'Profile',
      component: () => import(/* webpackChunkName: "Profile" */ '../views/ProFileView.vue')
    },
    {
      path: '/details/:id',
      name: 'Details',
      component: () => import(/* webpackChunkName: "Details" */ '../views/DetailView.vue')
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: () => import(/* webpackChunkName: "NotFound" */ '../views/404view.vue')
    },
  ],
  state: () => ({
    About: [],
  }),
  // 在路由切换时将数据保存到持久化状态
  // 该方法将在每次路由切换时调用
  persistState(to, from, savedState) {
    savedState.About = this.state.About;
  }
});

router.beforeEach(async (to, from, next) => {
  const token = localStorage.getItem('token');

  if (!token && to.path !== '/login') {
    // 没有 token，且目标路径不是登录页，直接导航到登录页
    next('/login');
  } else if (token) {
    try {
      const response = await AxiosUser();
      if (response.data.message === '成功获取到数据') {
        if (to.path === '/login') {
          // 有 token，且请求 API 成功，从登录页导航到首页
          next('/index');
        } else {
          // 有 token，且请求 API 成功，允许导航到目标页面
          next();
        }
      } else {
        // 有 token，但请求 API 失败或数据不符合预期，导航到登录页
        next('/login');
      }
    } catch (error) {
      // 请求 API 失败，无论当前路径是否为登录页，都导航到登录页
      next('/login');
    }
  } else {
    // 其他情况允许导航
    next();
  }
});

export default router;
