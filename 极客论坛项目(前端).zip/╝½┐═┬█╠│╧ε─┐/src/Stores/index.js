import { defineStore } from "pinia";
import AxiosDatas from "../JsTools/AxiosDatas";
import AxiosUsers from "../JsTools/AxiosUsers";
const useCounterStore = defineStore('counterStore', {
    state: () => ({
        count: 0,
        comment: null,
        userInfo: '',
        test: '',
        articles: [],
    }),
    actions: {
        async datas() {
            return await AxiosDatas();
        },
        async Users() {
            return await AxiosUsers();
        }
    }
});

export default useCounterStore;