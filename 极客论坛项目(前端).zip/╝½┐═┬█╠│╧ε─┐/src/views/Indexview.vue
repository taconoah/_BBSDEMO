<template>
    <div>
        <navpack foo="0" />
        <sectionpack />
    </div>
</template>

<script setup>
import navpack from '../components/nav.vue'
import sectionpack from '../components/Index.vue'

</script>

<style scoped>

</style>