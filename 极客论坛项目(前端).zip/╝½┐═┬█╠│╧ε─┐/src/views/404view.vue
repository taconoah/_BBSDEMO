<template>
  <div>not found</div>
</template>

<script setup>
</script>

<style scoped>
div {
  font-size: 32pt;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  text-transform: uppercase;
  letter-spacing: 2px;
  width: 100vw;
  height: 100vh;
  background-image: url("../assets/images/RE4wEaz.jpg");
}
</style>