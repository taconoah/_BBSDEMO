<template>
  <div>
    <navpack />
    <personal />
  </div>
</template>

<script setup>
import navpack from "../components/nav.vue";
import personal from "../components/personal.vue";
</script>

<style scoped>
</style>