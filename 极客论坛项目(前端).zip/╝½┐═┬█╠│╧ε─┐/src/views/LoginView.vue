<template>
  <div class="bg">
    <section>
      <form v-if="type == 0">
        <el-input v-model="ipt1" placeholder="请输入用户名" />
        <el-input v-model="ipt2" type="password" @keyup.enter="login()" placeholder="请输入密码" show-password />
      </form>
      <form v-else>
        <el-input v-model="ipt1" placeholder="请输入用户名" />
        <el-input v-model="ipt2" type="password" @keyup.enter="login()" placeholder="请输入密码" show-password />
        <el-input v-model="ipt3" placeholder="确认密码" show-password />
      </form>
      <div class="flex" v-if="type == 0">
        <el-button type="primary" @click="login()">登录</el-button>
        <el-button type="primary" @click="type = 1">注册</el-button>
      </div>
      <div class="flex" v-else>
        <el-button type="primary" @click="type = 0">返回</el-button>
        <el-button type="primary" @click="login()">注册</el-button>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref } from "vue";
import AxiosLogin from "../JsTools/AxiosLogin.js";
import AxiosRegister from "../JsTools/AxiosRegister.js";
import { ElMessage } from "element-plus";
const [ipt1, ipt2, ipt3, type] = [ref(""), ref(""), ref(""), ref(0)];
const login = (model = 0) => {
  if (ipt1.value == "" || ipt2.value == "")
    return ElMessage({
      message: "禁止输入为空",
      type: "warning",
    });
  if (model == 0 && ipt3.value == "") AxiosLogin(ipt1, ipt2);
  else {
    AxiosRegister(ipt1, ipt2, ipt3);
    type.value = 0;
  };
  [ipt1.value, ipt2.value, ipt3.value] = ["", "", ""];
};
</script>

<style scoped lang="scss">
.bg {
  width: 100vw;
  height: 100vh;
  background: no-repeat url("https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE4wwu6?ver=9a36");
  display: flex;
  justify-content: center;
  align-items: center;

  section {
    width: 500px;
    position: relative;

    form {
      height: auto;
    }

    .alert {
      top: -100px;
      position: absolute;
    }

    * {
      width: 100%;
      height: 50px;
      margin: 10px 0;
    }

    .flex {
      display: flex;

      *:nth-child(1) {
        margin-right: 10px;
      }
    }
  }
}
</style>