<template>
  <div class="bg">
    <section>
      <form>
        <el-input v-model="ipt1" placeholder="请输入用户名" />
        <el-input
          v-model="ipt2"
          type="password"
          @keyup.enter="login()"
          placeholder="请输入密码"
          show-password
        />
      </form>
      <div class="flex">
        <el-button type="primary" @click="login">登录</el-button>
        <el-button type="primary" @click="error">注册</el-button>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref } from "vue";
import AXIOSRequests from "../JsTools/AxiosRequest.js";
import { ElMessage } from "element-plus";
const ipt1 = ref("");
const ipt2 = ref("");
const login = async () => {
  if (ipt1.value == "" || ipt2.value == "")
    return ElMessage({
      message: "禁止输入为空",
      type: "warning",
    });
  await AXIOSRequests("http://127.0.0.1/api/login", "post", {
    name: ipt1.value,
    pwd: ipt2.value,
  }).then((val) => {
    if (val.data.message == "用户名或密码错误") {
      return ElMessage({
        message: val.data.message,
        type: "warning",
      });
    } else {
      localStorage.setItem("token", val.data);
      setTimeout(() => {
        location.reload();
      });
    }
  });
  ipt1.value = "";
  ipt2.value = "";
};
const error = () => {
  alert("目前接口未开放");
};
</script>

<style scoped lang="scss">
.bg {
  width: 100vw;
  height: 100vh;
  background: no-repeat
    url("https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE4wwu6?ver=9a36");
  display: flex;
  justify-content: center;
  align-items: center;
  section {
    width: 500px;
    position: relative;
    form {
      height: auto;
    }
    .alert {
      top: -100px;
      position: absolute;
    }
    * {
      width: 100%;
      height: 50px;
      margin: 10px 0;
    }
    .flex {
      display: flex;
      *:nth-child(1) {
        margin-right: 10px;
      }
    }
  }
}
</style>