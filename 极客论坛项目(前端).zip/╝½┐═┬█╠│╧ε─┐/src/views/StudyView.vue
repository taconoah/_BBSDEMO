<template>
  <div>
    <navpack foo="1" />
    <div class="container">
      <div class="tools">
        <section>
          <el-input
            v-model="SearchValue"
            @keyup.enter="SearchTools"
            placeholder="请输入要搜索的内容"
          />
          <el-button type="primary" @click="SearchTools">搜索</el-button>
        </section>
      </div>

      <div v-if="Store().articles.length == 0">
        <el-empty description="空" />
      </div>

      <div v-else-if="Store().articles.length != 0 && newArray == 0">
        <div v-for="(item, index) in Store().articles" :key="index">
          <router-link
            :to="{
              path: `/details/${item.title}`,
              query: { title: `${item.title}`, name: `${item.username}` },
            }"
          >
            <Leftpack
              :src="
                item.user_img != null
                  ? item.user_img
                  : 'https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0'
              "
            >
              <template #title> {{ item.title }}</template>
              <template #name>{{ item.username }}</template>
              <template #text> {{ item.content }}</template>
              <template #count>
                {{ item.comment && item.comment.length }}</template
              >
              <template #ArticleTime>{{
                item.publication_time_formatted
              }}</template>
            </Leftpack>
          </router-link>
        </div>
      </div>

      <div v-else>
        <div v-for="(item, index) in newArray" :key="index">
          <router-link
            :to="{
              path: `/details/${item.title}`,
              query: { title: `${item.title}`, name: `${item.username}` },
            }"
          >
            <Leftpack
              src="https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0"
            >
              <template #title> {{ item.title }}</template>
              <template #name>{{ item.username }}</template>
              <template #text> {{ item.content }}</template>
              <template #count>
                {{ item.comment && item.comment.length }}</template
              >
              <template #ArticleTime>{{
                item.publication_time_formatted
              }}</template>
            </Leftpack>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import navpack from "../components/nav.vue";
import Leftpack from "../components/left.vue";
import { ElMessage } from "element-plus";
import Store from "../Stores/index.js";
onMounted(() => {
  Store()
    .datas()
    .then((val) => (Store().articles = val));
});
const [SearchValue, newArray] = [ref(""), ref([])];
const SearchTools = () => {
  if (SearchValue.value.trim() == "") {
    ElMessage({
      message: "禁止输入内容为空",
      type: "warning",
    });
  } else {
    newArray.value = [];
    for (let i = 0; i < Store().articles.length; i++) {
      if (Store().articles[i].title.includes(SearchValue.value.trim()))
        newArray.value.push(Store().articles[i]);
    }
    newArray.value.length == 0
      ? ElMessage({
          message: "搜索内容为空",
          type: "success",
        })
      : ElMessage({
          message: `搜索文章共有:${newArray.value.length}篇`,
          type: "success",
        });
  }
  SearchValue.value = "";
};
</script>

<style scoped lang="scss">
.height-100 {
  height: 100px;
}
.container {
  max-width: 1024px;
  margin: 0 auto;
  .tools {
    margin: 20px 0;
    @extend .height-100;
    background-color: white;
    section {
      @extend .height-100;
      padding: 20px;
      display: flex;
      align-items: center;
      * {
        margin: 0 10px;
      }
    }
  }
}
</style>