<template>
    <div>
        <navpack />
        <About />
    </div>
</template>

<script setup>
import navpack from '../components/nav.vue'
import About from '../components/About.vue'
</script>

<style lang="scss" scoped></style>