<template>
    <div>
        <navpack foo="1"  />
        <About />
    </div>
</template>

<script setup>
import navpack from '../components/nav.vue'
import About from '../components/About.vue'
</script>

<style lang="scss" scoped></style>