function LogOut() {
    localStorage.removeItem("token");
    location.reload();
}

export default LogOut;