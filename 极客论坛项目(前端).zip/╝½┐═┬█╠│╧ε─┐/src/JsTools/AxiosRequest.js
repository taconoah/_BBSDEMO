import axios from 'axios';
const AXIOSRequests = async (href = 'http://127.0.0.1/api',Mymethod = 'get',  val = {},Header = '') => {
    return await axios({
        method: Mymethod,
        url: href,
        headers: {
            authorization: `Bearer ${Header}`
        },
        data: val,
    });
}
export default AXIOSRequests;