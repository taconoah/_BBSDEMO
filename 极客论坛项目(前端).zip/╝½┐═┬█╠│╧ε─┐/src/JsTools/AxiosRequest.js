import axios from 'axios';
const AXIOSRequests = async (href = 'http://127.0.0.1/api', Mymethod = 'get', val = {}, Header = '', model = 0) => {
    let obj = { authorization: `Bearer ${Header}` }
    if (model != 0) obj = Object.assign(obj, { 'Content-Type': 'multipart/form-data' })
    return await axios({
        method: Mymethod,
        url: href,
        headers: obj,
        data: val,
    });
}
export default AXIOSRequests;