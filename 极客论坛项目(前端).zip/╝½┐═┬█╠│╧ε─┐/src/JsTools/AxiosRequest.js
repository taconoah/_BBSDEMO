import axios from 'axios';
const AXIOSRequests = async (href = import.meta.env.VITE_REQUEST_SERVER, Mymethod = 'get', val = {}, Header = '', model = 0) => {
    let obj = { authorization: `Bearer ${Header}` }
    if (model != 0) obj = Object.assign(obj, { 'Content-Type': 'multipart/form-data' })
    return await axios({
        method: Mymethod,
        url: href,
        headers: obj,
        data: val,
    });
}
export default AXIOSRequests;