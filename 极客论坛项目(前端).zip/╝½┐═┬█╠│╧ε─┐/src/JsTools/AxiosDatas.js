import AxiosRequest from './AxiosRequest';
import { ref } from 'vue'
const AxiosDatas = async () => {
    let articles = ref();
    let comments = ref();
    const { VITE_REQUEST_SERVER, VITE_PAGES_article, VITE_PAGES_Comments } = import.meta.env;

    await AxiosRequest(
        `${VITE_REQUEST_SERVER}${VITE_PAGES_article}`,
        "get",
        {},
        localStorage.getItem("token")
    ).then(val => articles.value = val.data);

    await AxiosRequest(
        `${VITE_REQUEST_SERVER}${VITE_PAGES_Comments}`,

        "get",
        {},
        localStorage.getItem("token")
    ).then((val) => {
        comments.value = val.data;
        for (let i = 0; i < articles.value.length; i++) {
            articles.value[i].comment = [];
            for (let j = 0; j < comments.value.length; j++) {
                if (articles.value[i].article_id == comments.value[j].article_id) {
                    articles.value[i].comment.push(comments.value[j]);
                }
            }
        }
    });
    return articles;
}
export default AxiosDatas;