import AxiosRequest from './AxiosRequest';
import { ref } from 'vue'
const AxiosDatas = async () => {
    const articles = ref();
    const comments = ref();

    await AxiosRequest(
        "http://127.0.0.1/pages/article",
        "get",
        {},
        localStorage.getItem("token")
    ).then((val) => {
        articles.value = val.data;
    });

    await AxiosRequest(
        "http://127.0.0.1/pages/comments",
        "get",
        {},
        localStorage.getItem("token")
    ).then((val) => {
        comments.value = val.data;
        for (let i = 0; i < articles.value.length; i++) {
            articles.value[i].comment = [];
            for (let j = 0; j < comments.value.length; j++) {
                if (articles.value[i].article_id == comments.value[j].article_id) {
                    articles.value[i].comment.push(comments.value[j]);
                }
            }
        }
    });
    return articles;
}
export default AxiosDatas;