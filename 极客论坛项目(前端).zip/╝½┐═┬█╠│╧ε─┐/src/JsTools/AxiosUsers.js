import AxiosRequest from './AxiosRequest';

const AxiosUser = async () => await AxiosRequest(import.meta.env.VITE_REQUEST_SERVER, 'get', {}, localStorage.getItem('token'));
export default AxiosUser;