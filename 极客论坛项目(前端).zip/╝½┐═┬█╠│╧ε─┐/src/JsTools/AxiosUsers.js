import AxiosRequest from './AxiosRequest';

const AxiosUser = async () => await AxiosRequest('http://127.0.0.1/', 'get', {}, localStorage.getItem('token'));
export default AxiosUser;