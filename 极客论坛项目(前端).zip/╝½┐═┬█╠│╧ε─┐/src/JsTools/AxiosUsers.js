import AxiosRequest from './AxiosRequest';
import { ref } from 'vue'

const AxiosUser = async () => {
    return await AxiosRequest('http://127.0.0.1/','get',{},localStorage.getItem('token'))
}

export default AxiosUser;