import AXIOSRequests from "./AxiosRequest";
import { ElMessage } from 'element-plus';


async function ArticlesUpload(title,text) {
    if (title.length < 5 || text.length < 10) return ElMessage({
        message: "输入文章内容太短请重新编辑文章",
        type: 'warning',
    });
    let date = new Date();
    await AXIOSRequests('http://127.0.0.1/pages/articles/upload', 'post', {
        title: title,
        content: text,
        time: `${date.getFullYear()}-${date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1}-${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()} ${date.getHours() < 10 ? `0${date.getHours()}` : date.getHours()}:${date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes()}:${date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds()}`
    }, localStorage.getItem('token'));
    location.reload();

}
export default ArticlesUpload;