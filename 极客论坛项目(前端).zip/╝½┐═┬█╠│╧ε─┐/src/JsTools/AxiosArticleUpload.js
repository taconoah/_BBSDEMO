import AXIOSRequests from "./AxiosRequest";
import { ElMessage } from 'element-plus';


async function ArticlesUpload(title, text) {
    if (title.length < 5 || text.length < 10) return ElMessage({
        message: "输入文章内容太短请重新编辑文章",
        type: 'warning',
    });
    let date = new Date();
    const { VITE_REQUEST_SERVER, VITE_PAGES_Article_Upload } = import.meta.env;
    await AXIOSRequests(`${VITE_REQUEST_SERVER}${VITE_PAGES_Article_Upload}`, 'post', {
        title: title,
        content: text,
        time: `${date.getFullYear()}-${date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1}-${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()} ${date.getHours() < 10 ? `0${date.getHours()}` : date.getHours()}:${date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes()}:${date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds()}`
    }, localStorage.getItem('token')).then(val => {
        ElMessage({
            message: "发布文章成功",
            type: 'success',
        });
        setTimeout(() => location.reload(), 300);
    });
}
export default ArticlesUpload;