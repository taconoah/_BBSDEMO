import AXIOSRequests from "../JsTools/AxiosRequest";
import { ElMessage } from 'element-plus';
async function login(ipt1, ipt2) {
    await AXIOSRequests("http://127.0.0.1/api/login", "post", {
        name: ipt1.value,
        pwd: ipt2.value,
    }).then((val) => {
        if (val.data.message == "用户名或密码错误") {
            return ElMessage({
                message: val.data.message,
                type: "warning",
            });
        } else {
            localStorage.setItem("token", val.data);
            setTimeout(() => {
                location.reload();
            });
        }
    });
}

export default login;