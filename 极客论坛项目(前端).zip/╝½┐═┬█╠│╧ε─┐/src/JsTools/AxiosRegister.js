import AXIOSRequests from "../JsTools/AxiosRequest";
import { ElMessage } from 'element-plus';

async function register(ipt1, ipt2, ipt3) {
    if (ipt2.value != ipt3.value) return ElMessage({
        message: '密码不一致',
        type: 'warning',
    });
    let date = new Date();
    const { VITE_REQUEST_SERVER, VITE_USER_Register } = import.meta.env;
    await AXIOSRequests(`${VITE_REQUEST_SERVER}${VITE_USER_Register}`, "post", {
        name: ipt1.value,
        pwd: ipt2.value,
        time: `${date.getFullYear()}-${date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1}-${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()} ${date.getHours() < 10 ? `0${date.getHours()}` : date.getHours()}:${date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes()}:${date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds()}`
    }).then((val) => {
        ElMessage({
            message: val.data.status == 409 ? '用户名已存在' : '注册成功',
            type: val.data.status == 409 ? 'warning' : 'success',
        });
    });
}

export default register;