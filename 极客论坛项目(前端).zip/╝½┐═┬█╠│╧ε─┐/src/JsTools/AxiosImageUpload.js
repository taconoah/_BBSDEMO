import AXIOSRequests from "./AxiosRequest";
import { ElMessage } from "element-plus";
import Store from "../Stores/index.js";


const ImageUpload = async (file) => {
    let res = await Store().Users().then((val) => Store().userInfo = val.data);
    let formData = new FormData();
    formData.append('avatar', file);
    formData.append('data', JSON.stringify(res));
    await AXIOSRequests('http://127.0.0.1/api/profile', 'post', formData, localStorage.getItem('token')).then(val => {
        ElMessage({ type: "success", message: '上传成功' });
        setTimeout(() => location.reload(), 1000);
    });
}

export default ImageUpload;