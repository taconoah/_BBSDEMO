import AXIOSRequests from "./AxiosRequest";
import { ElMessage } from "element-plus";
import Store from "../Stores/index.js";


const ImageUpload = async (file) => {
    let res = await Store().Users().then((val) => Store().userInfo = val.data);
    const { VITE_REQUEST_SERVER, VITE_Upload_Profile } = import.meta.env;
    let formData = new FormData();
    formData.append('avatar', file);
    formData.append('data', JSON.stringify(res));
    await AXIOSRequests(`${VITE_REQUEST_SERVER}${VITE_Upload_Profile}`, 'post', formData, localStorage.getItem('token')).then(val => {
        ElMessage({ type: "success", message: '上传成功' });
        setTimeout(() => location.reload(), 1000);
    });
}

export default ImageUpload;