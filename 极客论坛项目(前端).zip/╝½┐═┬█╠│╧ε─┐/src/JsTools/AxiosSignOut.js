import AxiosRequest from "../JsTools/AxiosRequest";
import { ElMessage } from 'element-plus';

async function SignOut(val) {
    const { VITE_REQUEST_SERVER, VITE_USER_Singout } = import.meta.env;
    await AxiosRequest(`${VITE_REQUEST_SERVER}${VITE_USER_Singout}`, 'post', {
        name: val.username,
    }, localStorage.getItem("token")).then(val => {
        if (val.data.status == 200) {
            localStorage.removeItem('token');
            ElMessage({
                type: 'success',
                message: '注销成功'
            });
        } else if (val.data.status == 500) {
            ElMessage({
                type: 'error',
                message: '注销失败'
            });
        } else {
            console.error('出错');
        }
        location.href = "";
    });
}
export default SignOut;