import AxiosRequest from "../JsTools/AxiosRequest";
import { ElMessage } from 'element-plus';

async function SignOut(val) {
    await AxiosRequest('http://127.0.0.1/api/SignOut', 'post', {
        name: val.username,
    }, localStorage.getItem("token")).then(val => {
        if (val.data.status == 200) {
            localStorage.removeItem('token');
            return ElMessage({
                type: 'success',
                message:'注销成功'
            });
        } else if (val.data.status == 500) {
            return ElMessage({
                type: 'error',
                message:'注销失败'
            });
        } else {
            console.error('出错');
        }
    });
}
export default SignOut;