import AxiosRequest from './AxiosRequest';
import { ElMessage } from 'element-plus';
import router from '../router/index.js';
const { VITE_REQUEST_SERVER, VITE_PAGES_Article_DELETE } = import.meta.env;

const user = async (sf) => await AxiosRequest(VITE_REQUEST_SERVER, 'get', {}, localStorage.getItem("token")).then(val => sf == val.data.username ? true : false);
const Delete = async (article_id) => {
    await AxiosRequest(`${VITE_REQUEST_SERVER}${VITE_PAGES_Article_DELETE}`, 'post', {
        ID: article_id,
    }, localStorage.getItem("token")).then(val => {
        router.push('/index');
        return ElMessage({
            message: val.data.message,
            type: 'success',
        });
    });
}

export default {
    Delete, user
};