import AxiosRequest from './AxiosRequest';
import { ElMessage } from 'element-plus';
import router from '../router/index.js';
const user = async (sf) => {
    return await AxiosRequest('http://127.0.0.1/','get',{},localStorage.getItem("token")).then(val => {
        return sf == val.data.username ? true: false;
    });
}
const Delete = async (article_id) => {
    await AxiosRequest('http://127.0.0.1/pages/article/delete', 'post', {
        ID: article_id,
    }, localStorage.getItem("token")).then(val => {
        router.push('/index');
        return ElMessage({
            message: val.data.message,
            type: 'success',
        });
    });
} 

export default {
    Delete,user
};