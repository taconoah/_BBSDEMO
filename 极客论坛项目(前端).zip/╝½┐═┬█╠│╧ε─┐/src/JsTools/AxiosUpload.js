import AxiosRequest from './AxiosRequest';
import { ElMessage } from 'element-plus';
const upload = async (val, text) => {
    if (text.length == 0 || text.length < 10) return ElMessage({
        message: '禁止输入内容为空或者你输入的评论长度小于10',
        type: 'warning',
    });
    let date = new Date();
    await AxiosRequest('http://127.0.0.1/pages/comments/upload', 'post', {
        article_id: val.article_id,
        content: text,
        time: `${date.getFullYear()}-${date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1}-${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()} ${date.getHours() < 10 ? `0${date.getHours()}` : date.getHours()}:${date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes()}:${date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds()}`
    }, localStorage.getItem("token")).then(val => {
        ElMessage({
            message: '上传成功',
            type: 'success',
        })
        setTimeout(() => location.reload(), 500);
    });
}

export default upload;
