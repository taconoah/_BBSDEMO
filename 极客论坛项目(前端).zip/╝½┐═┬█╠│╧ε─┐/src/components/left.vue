<template>
  <div class="containe" :style="{ width: props.width }">
    <header>
      <img :src="props.src" alt="" />
      <span><slot name="name">数据加载中</slot></span>
    </header>
    <section>
      <h3><slot name="title">标题未插入</slot></h3>
      <p><slot name="text">文本记载中</slot></p>
    </section>
    <footer>
      <time><slot name="ArticleTime">发布时间未知</slot></time>
      <article>
        <el-icon size="25">
          <ChatLineRound />
        </el-icon>
        &nbsp;
        <p><slot name="count"></slot></p>
      </article>
    </footer>
  </div>
</template>

<script setup>
const props = defineProps(["src", "width"]);
</script>

<style scoped lang="scss">
.header {
  height: 50px;
}
.flex {
  display: flex;
}
.align-center {
  align-items: center;
}
.containe {
  height: auto;
  margin-bottom: 30px;
  background-color: white;
  border-radius: 10px;
  padding: 10px;
  header {
    height: 50px;
    @extend .flex;
    @extend .align-center;
    * {
      margin: 0 5px 0 0;
    }
    img {
      width: 50px;
      @extend .header;
      border-radius: 100%;
    }
  }
  section {
    padding: 20px 0;
    cursor: pointer;
    flex-grow: 1;
    p {
      white-space: pre-wrap;
    }
    h3 {
      &:hover {
        color: skyblue;
      }
    }
    *:nth-child(1) {
      margin: 0 0 10px 0;
    }
  }
  footer {
    @extend .header;
    @extend .flex;
    @extend .align-center;
    > * {
      margin: 0 5px;
    }
    article {
      @extend .flex;
      @extend .align-center;
    }
  }
}
</style>