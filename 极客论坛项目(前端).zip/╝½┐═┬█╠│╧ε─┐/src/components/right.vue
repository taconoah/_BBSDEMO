<template>
  <div class="containe">
    <header>
      <h2>
        <slot name="title"></slot>
      </h2>
    </header>
    <section>
      <p>
        <slot name="text"></slot>
      </p>
    </section>
  </div>
</template>

<script setup>
</script>

<style scoped lang="scss">
.height {
  height: 50px;
}
.flex {
  display: flex;
}
.containe {
  width: 350px;
  border-radius: 5px;
  box-shadow: 0px 1px 5px 0 #7b7b7b;
  margin-bottom: 20px;
  @extend .flex;
  flex-direction: column;
  background-color: white;
  header {
    padding: 0 10px;
    @extend .height;
    @extend .flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #ccc;
  }
  section {
    padding: 10px;
    @extend .flex;
    flex-grow: 1;
  }
}
</style>