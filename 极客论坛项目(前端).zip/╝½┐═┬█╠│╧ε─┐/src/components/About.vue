<template>
  <div>
    <article>
      <div class="AuthorInfo">
        <div class="title">
          <img
            :src="data && data.user_img"
            v-if="data && data.user_img != null"
            alt="文章用户头像"
          />
          <img
            v-else
            src="https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0"
            alt=""
          />
          {{ data && data.username }}
        </div>
        <el-button
          type="danger"
          class="text-style"
          v-if="blog == true"
          @click="ArticleTools.Delete(data.article_id)"
          round
          >删除文章</el-button
        >
      </div>
      <div class="RichText">
        <h2>{{ data && data.title }}</h2>
        <p style="white-space: pre-wrap">{{ data && data.content }}</p>
        <time>发布时间:{{ data && data.publication_time_formatted }}</time>
      </div>
    </article>

    <div class="AuthorButton">
      <el-input
        v-model="textarea"
        :rows="2"
        type="textarea"
        placeholder="尊重是打动人心的入场卷"
      />
      <el-button type="primary" @click="upload(data, textarea)" class="button"
        >提交</el-button
      >
    </div>
    <div class="Arthordatas" v-for="(item, index) in comment" :key="index">
      <div class="userInfo">
        <img
          :src="
            item.user_img == null
              ? 'https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0'
              : item.user_img
          "
          alt=""
        />
        {{ item.username }}
      </div>

      <div class="userText">
        {{ item.comment_text }}
      </div>
      <time>{{ item.formatted_publication_time }}</time>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRoute } from "vue-router";
import upload from "../JsTools/AxiosUpload";
import ArticleTools from "../JsTools/AxiosDeleteArticle.js";
import Store from "../Stores/index.js";
const [textarea, route, data, comment, blog] = [
  ref(``),
  useRoute(),
  ref(),
  ref(),
  ref(),
];
Store()
  .datas()
  .then((val) => {
    Store().articles = val;
    for (let i = 0; i < Store().articles.length; i++) {
      if (
        route.query.title == Store().articles[i].title &&
        route.query.name == Store().articles[i].username
      ) {
        data.value = Store().articles[i];
        comment.value = Store().articles[i].comment;
        break;
      }
    }
    ArticleTools.user(data && data.value.username).then(
      (val) => (blog.value = val)
    );
  });
</script>

<style scoped lang="scss">
.width {
  max-width: 1024px;
  background-color: white;
}
.flex-align {
  display: flex;
  align-items: center;
}
div {
  article {
    max-width: 1024px;
    background-color: white;
    padding: 10px;
    margin: 10px auto;
    .AuthorInfo {
      height: 50px;
      @extend .flex-align;

      justify-content: space-between;
      .title {
        @extend .flex-align;
        img {
          width: 50px;
          height: 50px;
          border-radius: 100%;
          margin-right: 10px;
        }
      }
    }
    .RichText {
      @extend .width;
      * {
        margin: 10px 0;
      }
    }
  }
  .AuthorButton {
    max-width: 1024px;
    margin: 0 auto;
    > * {
      margin: 10px 0;
    }
    .button {
      width: 100%;
    }
    .searchStyle {
      height: 50px;
    }
  }
  .Arthordatas {
    @extend .width;
    margin: 10px auto;
    padding: 10px;
    border-radius: 10px;
    > p {
      margin: 10px 0;
    }
    .userInfo {
      display: flex;
      align-items: center;
      img {
        width: 50px;
        height: 50px;
        margin-right: 10px;
        border-radius: 100%;
      }
    }
    .userText {
      white-space: pre-wrap;
      line-height: 30px;
      margin: 10px 0;
    }
  }
}
.text-style {
  line-height: 50px;
  letter-spacing: 2px;
}
</style>