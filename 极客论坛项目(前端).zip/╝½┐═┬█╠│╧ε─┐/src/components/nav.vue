<template>
  <div class="nav">
    <div class="container">
      <div class="logo">
        <el-icon color="#409EFC" size="40">
          <Position />
        </el-icon>
      </div>
      <ul class="list">
        <li
          v-for="(item, index) in navlist"
          :key="index"
          :class="{ nav_active: Number(pages.foo) === index }"
        >
          <router-link :to="getRoutePath(index)">{{ item }}</router-link>
        </li>
      </ul>

      <div class="login">
        <router-link to="/Profile">
          <img :src="Store().userInfo.avatar" v-if="Store().userInfo.avatar !== false" class="avatar" alt="" />
          <el-icon size="20" color="white" v-else><UserFilled /></el-icon>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import Store from "../Stores/index.js";
Store()
  .Users()
  .then((val) => Store().userInfo = val.data);
const pages = defineProps(["foo"]);
const navlist = reactive(["首页", "学习"]);
const getRoutePath = (index) => {
  const paths = ["/", "/study"];
  return paths[index];
};
</script>

<style scoped lang="scss">
.nav {
  height: 50px;
  background-color: white;
  box-shadow: 0px 1px 0px 0px #ccc;
  .container {
    max-width: 1024px;
    height: 50px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    .avatar {
      width: 40px;
      height: 40px;
      border-radius: 100%;
    }
    .list {
      display: flex;
      li {
        height: 50px;
        line-height: 50px;
        letter-spacing: 2px;
        margin: 0 10px;
        transition: 0.2s all;
        &:hover {
          cursor: pointer;
          color: #337ecc;
        }
      }
    }
    .login {
      width: 40px;
      height: 40px;
      text-align: center;
      line-height: 50px;
      background-color: #ccc;
      border-radius: 100%;
    }
  }
}
.nav_active {
  border-bottom: 2px solid #337ecc;
  a {
    color: #337ecc;
  }
}
</style>