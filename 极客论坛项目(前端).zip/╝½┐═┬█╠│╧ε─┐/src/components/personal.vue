<template>
  <div class="contain">
    <header>
      <img
        src="https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE4wppn?ver=c334"
        alt=""
      />
    </header>
    <h2>我的文章</h2>
    <article>
      <div class="left">
        <div v-if="articleList.length == 0" class="notArticle">
          <h3>你还没发布过文章呢</h3>
        </div>
        <div v-else v-for="(item, index) in articleList" :key="index">
          <router-link
            :to="{
              path: `/details/${item.title}`,
              query: { title: `${item.title}`, name: `${item.username}` },
            }"
          >
            <LeftPack
              width="635"
              src="https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0"
            >
              <template #name> {{ item.username }} </template>
              <template #title> {{ item.title }} </template>
              <template #text> {{ item.content }} </template>
              <template #ArticleTime>
                {{ item.publication_time_formatted }}
              </template>
              <template #count> {{ item.comment.length }} </template>
            </LeftPack>
          </router-link>
        </div>
      </div>
      <div class="right">
        <AsidePack>
          <template #title> 公告 </template>
          <template #text>
            <p class="asideList">本项目由一人开发较为不完善</p>
            <p class="asideList">如有BUG欢迎联系:XXXX</p>
          </template>
        </AsidePack>
        <AsidePack>
          <template #title>用户信息</template>
          <template #text>
            <p class="asideList">
              <span>用户:</span>{{ Store().userInfo.username }}
            </p>
            <p class="asideList">
              <span>身份:</span>{{ Store().userInfo.identity }}
            </p>
            <p class="asideList">
              <el-button type="danger" @click="LogOut">登出</el-button>
            </p>
          </template>
        </AsidePack>
      </div>
    </article>
    <section>
      <h2>发布文章</h2>
      <p>
        <textarea
          cols="30"
          rows="1"
          v-model.lazy="title"
          placeholder="请输入你要文章标题..."
        ></textarea>
        <textarea
          cols="30"
          rows="10"
          v-model.lazy="content"
          placeholder="请输入文章内容..."
        ></textarea>
      </p>
      <el-button
        type="success"
        @click="AxiosArticleUpload(title, content)"
        >发布</el-button
      >
    </section>
  </div>
</template>

<script setup>
import AsidePack from "./right.vue";
import LeftPack from "./left.vue";
import Store from "../Stores/index.js";
import AxiosArticleUpload from "../JsTools/AxiosArticleUpload.js";
import { ref } from "vue";
const [articleList, title, content] = [ref([]), "", ""];
Store()
  .Users()
  .then((val) => {
    Store().userInfo = val.data;
  });
Store()
  .datas()
  .then((val) => {
    Store().articles = val;
    for (let i = 0; i < Store().articles.length; i++) {
      if (Store().articles[i].username == Store().userInfo.username)
        articleList.value.push(Store().articles[i]);
    }
  });
function LogOut() {
  localStorage.removeItem('token');
  location.reload();
}
</script>

<style scoped lang="scss">
.margin-bottom20 {
  margin-bottom: 20px;
}
.section-all {
  width: 100%;
  margin: 10px 0;
}
.textarea {
  font-size: 16pt;
  letter-spacing: 2px;
}
.asideList {
  padding: 5px 0;
}
.contain {
  max-width: 1024px;
  margin: 0 auto;
  header {
    height: 200px;
    background-color: orangered;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
  h2 {
    margin: 10px 0;
  }
  section {
    textarea,
    button {
      @extend .section-all;
    }
    textarea {
      @extend .textarea;
      padding: 10px;
      &::placeholder {
        @extend .textarea;
      }
    }
  }
  article {
    max-width: 1024px;
    display: flex;
    justify-content: space-between;

    .left {
      min-width: 635px;
      height: auto;
      margin-right: 20px;
      .notArticle {
        height: 200px;
        background-color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        font-size: 17pt;
      }
    }
  }
}
</style>