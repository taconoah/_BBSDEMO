<template>
  <div class="container">
    <div class="left">
      <div v-for="(item, index) in Store().articles" :key="index">
        <router-link
          :to="{
            path: `/details/${item.title}`,
            query: { title: `${item.title}`, name: `${item.username}` },
          }"
        >
          <Leftpack
            width="635px"
            src="https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0"
          >
            <template #title> {{ item.title }}</template>
            <template #name>{{ item.username }}</template>
            <template #text> {{ item.content }}</template>
            <template #count>{{
              item.comment && item.comment.length
            }}</template>
            <template #ArticleTime>{{
              item.publication_time_formatted
            }}</template>
          </Leftpack>
        </router-link>
      </div>
    </div>
    <div class="right">
      <Rightpack>
        <template #title>公告</template>
        <template #text>
          <p class="asideList">本项目由一人开发较为不完善</p>
          <p class="asideList">如有BUG欢迎联系:XXXX</p>
        </template>
      </Rightpack>
      <Rightpack>
        <template #title>用户信息</template>
        <template #text>
          <p class="asideList"><span>用户:</span>{{ Store().userInfo.username }}</p>
          <p class="asideList"><span>身份:</span>{{ Store().userInfo.identity }}</p>
        </template>
      </Rightpack>
    </div>
  </div>
</template>

<script setup>
import Leftpack from "./left.vue";
import Rightpack from "./right.vue";
import Store from "../Stores/index.js";
Store()
  .datas()
  .then((val) => {
    Store().articles = val;
  }).catch((err) => {
    Store().articles = [{title:'null',username:'null',content:'null'}];
  });
Store().Users().then(val => {
  Store().userInfo = val.data;
}).catch((err) => {
    Store().userInfo = [{title:'null',username:'null',content:'null'}];
  });
</script>

<style scoped lang="scss">
.container {
  max-width: 1024px;
  margin: 20px auto;
  border-radius: 10px;
  display: flex;
  justify-content: space-between;
  .left {
    margin-right: 20px;
  }
}
.asideList {
  padding:5px;

  span {
    margin-right: 5px;
  }
}
</style>