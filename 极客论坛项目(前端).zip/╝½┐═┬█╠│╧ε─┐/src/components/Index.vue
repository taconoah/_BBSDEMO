<template>
  <div class="container">
    <div class="left" v-if="Store().articles.length != 0">
      <div v-for="(item, index) in Store().articles" :key="index">
        <router-link
          :to="{
            path: `/details/${item.title}`,
            query: { title: `${item.title}`, name: `${item.username}` },
          }"
        >
          <Leftpack
            width="635px"
            :src="
              item.user_img != null
                ? item.user_img
                : 'https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0'
            "
          >
            <template #title> {{ item.title }}</template>
            <template #name>{{ item.username }}</template>
            <template #text> {{ item.content }}</template>
            <template #count>{{
              item.comment && item.comment.length
            }}</template>
            <template #ArticleTime>{{
              item.publication_time_formatted
            }}</template>
          </Leftpack>
        </router-link>
      </div>
    </div>
    <div class="left" v-else>
      <el-empty description="空" />
    </div>
    <div class="right">
      <Rightpack>
        <template #title>公告</template>
        <template #text>
          <p class="asideList">本项目由一人开发较为不完善</p>
          <p class="asideList">如有BUG欢迎联系:XXXX</p>
        </template>
      </Rightpack>
      <Rightpack>
        <template #title>用户信息</template>
        <template #text>
          <div class="avatar">
            <img
              :src="Store().userInfo.avatar"
              v-if="Store().userInfo.avatar"
              class="avatar"
              alt="用户头像"
            />
            <img
              v-else
              src="https://ts1.cn.mm.bing.net/th/id/R-C.b0ea268fa1be279d112489ce83ad4696?rik=qItsh%2fBiy33hlg&riu=http%3a%2f%2fwww.quazero.com%2fuploads%2fallimg%2f140303%2f1-140303215009.jpg&ehk=S6PLWamt%2bMzQV8uO9ugcU5d5M19BpXtCpNz2cRJ7q9M%3d&risl=&pid=ImgRaw&r=0"
              alt="这是头像"
            />
            <section>
              <p class="asideList">
                <span>用户:</span>{{ Store().userInfo.username }}
              </p>
              <p class="asideList">
                <span>身份:</span>{{ Store().userInfo.identity }}
              </p>
            </section>
          </div>
          <el-button type="danger" class="btn" @click="LogOut()"
            >登出</el-button
          >
        </template>
      </Rightpack>
    </div>
  </div>
</template>

<script setup>
import Leftpack from "./left.vue";
import Rightpack from "./right.vue";
import LogOut from "../JsTools/AxiosLogOut.js";
import Store from "../Stores/index.js";
Store()
  .datas()
  .then((val) => (Store().articles = val))
  .catch((err) => {
    Store().articles = [
      {
        title: "数据请求失败",
        username: "数据请求失败",
        content: "数据请求失败",
      },
    ];
  });
Store()
  .Users()
  .then((val) => (Store().userInfo = val.data))
  .catch((err) => {
    Store().userInfo = [
      {
        title: "数据请求失败",
        username: "数据请求失败",
        content: "数据请求失败",
      },
    ];
  });
</script>

<style scoped lang="scss">
$five: 5px;
.container {
  max-width: 1024px;
  margin: 20px auto;
  border-radius: 10px;
  display: flex;
  justify-content: space-between;
  .left {
    margin-right: 20px;
    width: 100%;
  }
}
.avatar {
  width: 330px;
  display: flex;
  align-items: center;
  margin: $five 0;
  .asideList {
    padding: $five;

    span {
      margin-right: $five;
    }
  }
  img {
    width: 70px;
    height: 70px;
    border-radius: 100%;
    margin-right: 10px;
  }
}
.btn {
  width: 100%;
}
</style>